/*
 * Copyright (C) 2016-2020 phantom.bot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

$.lang.register('killcommand.self.1', '$1 рещил суициднуться... И сделал это удачно.');
$.lang.register('killcommand.self.2', '$1 причина смерти не установлена.');
$.lang.register('killcommand.self.3', '$1 был убит валуном скатившемся с высоты ЧСВ стримера.');
$.lang.register('killcommand.self.4', '$1 взорван.');
$.lang.register('killcommand.self.5', '$1 забыл как дышать и задохнулся.');
$.lang.register('killcommand.self.6', '$1 learned that cellular respiration uses oxygen, not sand.');
$.lang.register('killcommand.self.7', '$1 мёртв.');
$.lang.register('killcommand.self.8', '$1 пытался подружиться с диким гризли. Не удалось.');
$.lang.register('killcommand.self.9', '$1 задохнулся.');
$.lang.register('killcommand.self.10', '$1 решил проверить пространственно-временной континум. Засосало.');
$.lang.register('killcommand.self.11', '$1 испепелён.');
$.lang.register('killcommand.self.12', '$1 утонул.');
$.lang.register('killcommand.self.13', '$1 перестал существовать в этом бренном мире.');
$.lang.register('killcommand.self.14', '$1 был соблазнён @Refleksiya');
$.lang.register('killcommand.self.15', '$1 забыл что на 0 делить нельзя и разделил!');
$.lang.register('killcommand.self.16', '$1 был похищен инопланетянами.');
$.lang.register('killcommand.self.17', '$1 упал с лестницы.');
$.lang.register('killcommand.self.18', '$1 решил полазать по деревьям, ветка не выдержала веса.');
$.lang.register('killcommand.self.19', '$1 обвалился шифер при ремонте крыши.');
$.lang.register('killcommand.self.20', '$1 сгорел на заводе.');
$.lang.register('killcommand.self.21', '$1 убит молнией пока писал на рельсы.');
$.lang.register('killcommand.self.22', '$1 забыл что нужно кушать и умер.');
$.lang.register('killcommand.self.23', '$1 один удар в печень отнимит дар речи.');
$.lang.register('killcommand.self.24', '$1 гравитация беспощадна.');
$.lang.register('killcommand.self.25', '$1\'s plead for death was answered.');
$.lang.register('killcommand.self.26', '$1\'s vital organs were ruptured.');
$.lang.register('killcommand.self.27', '$1\'s innards were made outwards.');
$.lang.register('killcommand.self.28', '$1 был убит. Не спрашивайте как.');
$.lang.register('killcommand.self.29', '$1 удалён из этого чата.');
$.lang.register('killcommand.self.30', '$1 расщиплён на молекулы, буквально.');
$.lang.register('killcommand.self.31', '$1 истёк кровью.');
$.lang.register('killcommand.self.32', '$1 Еда - это дар от Бога. Специи - это подарок от дьявола. Я думаю, это было слишком острым для вас.');
$.lang.register('killcommand.self.33', '$1 умер из-за взрыва автомобиля!');
$.lang.register('killcommand.self.34', '$1 сгорел на работе');
$.lang.register('killcommand.self.35', '$1 копал в огороде и выкопал смерть!');
$.lang.register('killcommand.self.36', '$1 хотел побить рекорд по задержке дыхания. Хватило на 25 секунд!');
$.lang.register('killcommand.self.37', '$1 burned to death.');
$.lang.register('killcommand.self.38', '$1 *пшш* *пшш* ракета земля - земля достигла цели!');
$.lang.register('killcommand.self.39', '$1 замёрз.');
$.lang.register('killcommand.self.40', '$1 закидан камнями.');
$.lang.register('killcommand.self.41', '$1 пытаться плавать в ядовитых отходах не лучшая затея.');
$.lang.register('killcommand.self.42', '$1 подгорел в лаве.');
$.lang.register('killcommand.self.43', '$1 три икс в кубе плюс константа, ну что там ?');
$.lang.register('killcommand.self.44', '$1 взорвал.');
$.lang.register('killcommand.self.45', '$1 fell into a patch of fire.');
$.lang.register('killcommand.self.46', '$1 fell out of a plane.');
$.lang.register('killcommand.self.47', '$1 went up in flames.');
$.lang.register('killcommand.self.48', '$1 сделал паунс в окно.');
$.lang.register('killcommand.self.49', '$1 прыгнул с парашютом, но забыл парашют.');
$.lang.register('killcommand.self.50', '$1 сбит машиной.');
$.lang.register('killcommand.self.51', '$1 был поражён вспышкой фар грузовика.');
$.lang.register('killcommand.self.52', '$1 покончил жизнь самоубийством. Пока, чят!');
$.lang.register('killcommand.self.53', '$1 земля в иллюминаторе, земля в иллюминаторе видна, а ты в гробу.');


$.lang.register('killcommand.other.1', '$1 убит $2 при помощи рога единорога!');
$.lang.register('killcommand.other.2', '$2 убит $1!');
$.lang.register('killcommand.other.3', '$2 был изуродован $1 и переодет в костюм петушка.');
$.lang.register('killcommand.other.4', '$2 был разорван на части $1, бооооожечки!');
$.lang.register('killcommand.other.5', '$2 был брутально убит $1 автомобилем марки ОКА!');
$.lang.register('killcommand.other.6', '$1 брошен $2 в клетку к голодным школьницам.');
$.lang.register('killcommand.other.7', '$1 genetically modified a Venus flytrap to grow abnormally large, and trapped $2 in a room with it.');
$.lang.register('killcommand.other.8', '$1 shanked $2\'s butt, over and over again.');
$.lang.register('killcommand.other.9', '$1 just wrote $2\'s name in their Death Note.');
$.lang.register('killcommand.other.10', '$1 put $2 out of their misery.');
$.lang.register('killcommand.other.11', '$1 destroyed $2!');
$.lang.register('killcommand.other.12', '$1 atacó a $2 con un consolador grande!');
$.lang.register('killcommand.other.13', '$2 was poked a bit too hard by $1 with a spork!');
$.lang.register('killcommand.other.14', 'ZA WARUDO! $1 stopped time and throw hundreds of knives at $2. END!');
$.lang.register('killcommand.other.15', '$1 attacked $2 with a rusty spork...and managed to kill $2 with very little effort.');
$.lang.register('killcommand.other.16', '$1 stole a car known as \'KITT\' and ran over $2.');
$.lang.register('killcommand.other.17', '$1 tickled $2 to death!');
$.lang.register('killcommand.other.18', '$2\'s skull was crushed by $1!');
$.lang.register('killcommand.other.19', '$2 is in several pieces after a tragic accident involving $1 and cutlery.');
$.lang.register('killcommand.other.20', '$1 licked $2 until $2 was squishy, yeah.. squishy.');
$.lang.register('killcommand.other.21', '$1 catapulted a huge load of rusty sporks on to $2. $2 died.');
$.lang.register('killcommand.other.22', '$1 ran out of rusty sporks and unicorn horns to kill $2 with, so instead they used a rusty hanger.');
$.lang.register('killcommand.other.23', '$1 came in like a mystical being of awesomeness and destroyed $2!');
$.lang.register('killcommand.other.24', '$2 drowned whilst trying to escape from $1');
$.lang.register('killcommand.other.25', '$2 walked into a cactus while running from $1');
$.lang.register('killcommand.other.26', '$2 was attacked by $1 behind a Taco Bell.');
$.lang.register('killcommand.other.27', '$1 went back in time to prevent himself from killing $2, apparently the time machine landed on $2 when $1 jumped back in time.');
$.lang.register('killcommand.other.28', '$1 rekt $2 30-4 by doing a 360 no-scope.');
$.lang.register('killcommand.other.33', '$1 struck the final blow and ended $2.');

/** Add "(jail)" at the start of the lang for the user to get timed out for the jailTime you set. You can also use $3 for the jail timeout time to be displayed. $4 = botname. */
$.lang.register('killcommand.other.29', '(jail) $1 tried to kill $2 with a unicorn\'s horn, but police showed up before $1 had time.');
$.lang.register('killcommand.other.30', '(jail) $1 tried to murder $2, but swat was hiding in the bushes and jumped on $1 before it could be done.');
$.lang.register('killcommand.other.31', '(jail) $1 was going to hit $2 with a hammer. However $2 was trained in the Secret Nippon Arts!');
$.lang.register('killcommand.other.32', '(jail) $4 was paid by $1 to assassinate $2. $1\'s plan failed because $4 was actually a undercover officer!');
$.lang.register('killcommand.other.44', '(jail) $1 attacked $2 with a plastic spoon, but then suddenly a swarm of police surrounded $1 and detained them.');
$.lang.register('killcommand.other.45', '(jail) $2 is protected by an unknown force which repels $1.');
/** Jail End **/

$.lang.register('killcommand.other.34', '$1 was justly ended by $2.');
$.lang.register('killcommand.other.35', '$1 взорван ракетой $2.');
$.lang.register('killcommand.other.36', '$1 застрелен из лазерной пушки $2.');
$.lang.register('killcommand.other.37', '$1 пытался плавать в лаве пока спасал $2.');
$.lang.register('killcommand.other.38', '$1 был закончен в этом мире $2.');
$.lang.register('killcommand.other.39', '$1 доставлен на почту взорванным $2.');
$.lang.register('killcommand.other.40', '$1 забит лапками $2 до смерти.');
$.lang.register('killcommand.other.41', '$1 заснайплен $2 и отправлен в морг!');
$.lang.register('killcommand.other.42', '$1 обнял $2 слишком крепко.');
$.lang.register('killcommand.other.43', '$1 отправлен $2 в невероятную ферму в майнкрафте.');

$.lang.register('killcommand.jail.timeout.usage', 'Usage: !jailtimeouttime (amount in seconds)');
$.lang.register('killcommand.jail.timeout.set', 'Jail timeout time set to: $1 seconds.');

$.lang.register('killcommand.console.loaded', 'Found kill command messages: $1 self, $2 other.');
