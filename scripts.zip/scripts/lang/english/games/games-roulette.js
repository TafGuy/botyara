/*
 * Copyright (C) 2016-2020 phantom.bot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

$.lang.register('roulette.win.1', 'В шахматах выигрывает каждый, а вот в русской рулетке нет. @@$1 сегодня твой день');
$.lang.register('roulette.win.2', 'Воу воу воу, @$1 спрячь ствол, нет, не жми ! НЕТ ! А ты тот ещё ссаный лакерок');
$.lang.register('roulette.win.3', 'Трудно играть в русскую рулетку, катаясь на американских горках, но у @$1 получается');
$.lang.register('roulette.win.4', 'Так так тааак, что тут у нас ? @$1 жмёт на курок и .... Остаётся в чате');
$.lang.register('roulette.win.5', 'Плохому танцору яйца мешают, а @$1 голова. И она продолжает ему мешать, пули не было.');
$.lang.register('roulette.win.6', 'Жизнь - игра. Ярик - батя. Модер - сосал. А @$1 ссаный лакерок выживший в русской рулетке.');
$.lang.register('roulette.win.7', 'Dori me. Interimo adapare dori me. А, не, показалось @$1 живой, только в штаны ссыкнул чуток.');

$.lang.register('roulette.lost.1', 'Достал ствол из широких штанин nskaPohChamp cakeRevolver и ножки @$1 подкосились cakeF .');
$.lang.register('roulette.lost.2', '@$1 решил проверить своё везение, не в этот раз, сынище. Покойся с миром.');
$.lang.register('roulette.lost.3', 'Револьвер в руках у @$1. Курок взведён, выстрел. И только тушка осталась на стуле. FATALITY');
$.lang.register('roulette.lost.4', 'Ничто не предвещало беды, но @$1 решил суициднуться. *Осуждающий вздох* F');
$.lang.register('roulette.lost.5', '@$1 взвёл револьвер себе к веску. Выстрел @$1 выживает. Неожиданный звонок в дверь и курок нажимается второй раз. В этот раз не повезло !');
$.lang.register('roulette.lost.6', 'Курок взведён, @$1 нажимает на него. *БАМ* вызывайте коронера, у нас труп.');
$.lang.register('roulette.lost.7', 'День был чудесным, но чат нашёл @$1 мёртвым. Андрюха, по коням, у нас труп, возможен криминал.');

$.lang.register('roulette.set.timeouttime.success', 'The !roulette timeout has been set to $1 seconds!');
$.lang.register('roulette.set.timeouttime.usage', 'Usage: !roulette timeout [seconds]');
$.lang.register('roulette.timeout.notifyuser', 'You have lost the roulette and have been timed out for $1 seconds.');
$.lang.register('roulette.console.loaded', 'Found Roulette messages: $1 wins, $2 losts.');
